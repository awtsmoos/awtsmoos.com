---
name: tunnel-workflow
description: Operate the live Awtsmoos tunnel for authorized device connection, current schema discovery, injected instructions, durable plans, asynchronous jobs, bounded multitasking and recovery. Use for substantial tunnel-backed work and continuation.
---

<!-- B"H -->
<!-- Boruch Hashem -->
<!-- Blessed is He -->

Read ../instructions/references/MODERN_TUNNEL_CONTRACT.md, TUNNEL_NATIVE_PLANNING.md and STABILITY_AND_MULTITASKING.md in that same references directory. Discover tools actually exposed in this host, bootstrap and retain the authorized immutable device route.

Resolve applicable instructions with task, paths, runtime and evidence tag awtsmoos-shliach. Fetch required packs in full before writing. Resume the matching mission/plan; save finite operational plans and verification checklists there. Keep the legacy mission and debt references available on demand.

Use awtsmoos_action_schema to discover contracts; its internal action is actionSchemaTrace, never actionSchema. Registered future actions use awtsmoos_tunnel_action and its params object. Discover exact names and fields rather than guessing. Cache schemas/instructions only by returned version and refresh after scope, generation or release changes.

Run independent work concurrently with a measured bound. Keep health, status and cancellation responsive; serialize conflicting writes and verify their hashes/readback. Start long commands as owned asynchronous jobs, retain identifiers and use bounded output pages. Never replay an accepted write after a timeout; observe durable receipts first.

Persist factual checkpoints with identifiers, completed checks, pending jobs, blockers and next authorized steps. Continue independent authorized work while waiting. Give a concrete update at least once per minute. Background continuation requires an actual persistent worker; a skill does not create one or extend the host's turn lifetime. Report source tests, production routing, authenticated calls and host behavior separately.

## Shared tunnel skill discovery and verified continuation

Read ../instructions/references/DURABLE_WORK_AND_CONNECTION_RECOVERY.md for the current external-agent skill catalog, bounded reference retrieval, durable work actions, connection diagnostics and frontend release gates. Treat the live action schemas as authoritative.

## CSS and actual screenshot review

Read ../instructions/references/CSS_AND_EXTERNAL_VISUAL_VERIFICATION.md before frontend edits or UI completion claims. Fix the owning cascade rather than layering overrides; verify exact-source behavior in real Chrome, transfer screenshots into the external agent host with byte/hash checks, open the images with its image tools, and record unresolved defects before release.

## Resumable clients and channel evidence

Read ../instructions/references/RESUMABLE_CLIENT_AND_CHANNEL_EVIDENCE.md when diagnosing a flap, resuming interrupted commands, coordinating parallel work or upgrading the runtime. Preserve complete pending receipts and require terminal exit/output proof. Use the existing queues, checkpoints and frontend gates.

## Diagnose the living route before risky work

When available, call the first-class read-only `awtsmoos_tunnel_doctor` against the immutable routeReference discovered by `awtsmoos_discover_device`. It independently reports connection, command capability, OAuth command scope, device grant, and freshness of execution evidence. `canAttemptNativeCommand` is not proof that a shell command completed, and `commandSuccessCertified` is not a substitute for the terminal response for this exact operation. When the doctor is absent on an older server, use discovery and status without inventing its result. Verify actual command success with an authorized harmless command, checking stdout, stderr and integer exitCode; if authorization is absent, explain the precise missing permission rather than silently bypassing it. Do not retry uncertain mutations or broaden an OAuth scope through tools.

## Binary screenshots and external sharing

Read ../instructions/references/ARTIFACTS_AND_PUBLIC_LINKS.md. Capture only exact approved Chrome targets, verify binary bytes and recipient-host readback, and never fabricate a sandbox path. Temporary public artifacts require explicit consent plus tunnel.admin; revoke using the returned artifactId. A Mac runtime on 1.0.671 may lack the newer exact-target capture action until secure pairing and upgrade complete.
